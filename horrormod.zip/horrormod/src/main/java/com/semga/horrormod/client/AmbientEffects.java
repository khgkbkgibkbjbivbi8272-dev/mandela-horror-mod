package com.semga.horrormod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.semga.horrormod.network.AmbientEventPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Лёгкие фоновые эффекты, не связанные с основным скримером:
 * мигание света, силуэт за спиной, кадр помех.
 * Каждый эффект живёт максимум пару тиков — они должны быть почти незаметны,
 * "было это или показалось".
 */
@Mod.EventBusSubscriber(modid = "horrormod", value = Dist.CLIENT)
public class AmbientEffects {

    private static final ResourceLocation SILHOUETTE_TEXTURE =
            new ResourceLocation("horrormod", "textures/gui/silhouette.png");
    private static final ResourceLocation STATIC_NOISE_TEXTURE =
            new ResourceLocation("horrormod", "textures/gui/static_noise.png");

    private static int lightFlickerTicks = 0;
    private static int silhouetteTicks = 0;
    private static int glitchTicks = 0;

    public static void trigger(AmbientEventPacket.Type type) {
        switch (type) {
            case LIGHT_FLICKER -> lightFlickerTicks = 2;   // один короткий "моргнул свет"
            case SILHOUETTE -> silhouetteTicks = 4;        // силуэт мелькнул и пропал
            case SCREEN_GLITCH -> glitchTicks = 2;         // один кадр помех
        }
    }

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.HELMET.id())) return;
        if (lightFlickerTicks <= 0 && silhouetteTicks <= 0 && glitchTicks <= 0) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        if (lightFlickerTicks > 0) {
            // Мгновенное затемнение всего экрана — "свет мигнул"
            graphics.fill(0, 0, width, height, 0x000000 | (150 << 24));
            lightFlickerTicks--;
        }

        if (silhouetteTicks > 0) {
            // Полупрозрачный силуэт у края экрана — "за спиной", исчезает как только обернулся
            int size = height / 2;
            int x = width - size - 20;
            int y = height - size;
            RenderSystem.setShaderColor(1F, 1F, 1F, 0.35F);
            graphics.blit(SILHOUETTE_TEXTURE, x, y, size, size, 0, 0, 128, 128, 128, 128);
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            silhouetteTicks--;
        }

        if (glitchTicks > 0) {
            RenderSystem.setShaderColor(1F, 1F, 1F, 0.5F);
            graphics.blit(STATIC_NOISE_TEXTURE, 0, 0, width, height, 0, 0, 256, 256, 256, 256);
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            glitchTicks--;
        }

        RenderSystem.disableBlend();
    }
}
