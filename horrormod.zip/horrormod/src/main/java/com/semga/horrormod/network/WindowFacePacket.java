package com.semga.horrormod.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Показать/скрыть улыбающееся лицо "в окне" по конкретным координатам блока.
 * Рендерится клиентом как billboard прямо на месте окна (см. WindowFaceRenderer).
 */
public class WindowFacePacket {

    private final boolean show;
    private final BlockPos pos;

    public WindowFacePacket(boolean show, BlockPos pos) {
        this.show = show;
        this.pos = pos;
    }

    public static void encode(WindowFacePacket packet, FriendlyByteBuf buf) {
        buf.writeBoolean(packet.show);
        buf.writeBlockPos(packet.pos);
    }

    public static WindowFacePacket decode(FriendlyByteBuf buf) {
        boolean show = buf.readBoolean();
        BlockPos pos = buf.readBlockPos();
        return new WindowFacePacket(show, pos);
    }

    public static void handle(WindowFacePacket packet, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            if (packet.show) {
                com.semga.horrormod.client.WindowFaceRenderer.show(packet.pos);
            } else {
                com.semga.horrormod.client.WindowFaceRenderer.hide();
            }
        });
        ctx.setPacketHandled(true);
    }
}
