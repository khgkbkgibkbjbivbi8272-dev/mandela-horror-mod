package com.semga.horrormod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.semga.horrormod.network.JumpscarePacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

/**
 * Полноэкранный скример.
 *
 * FULL_DEATH_SEQUENCE (сценарий паралича, ~5 сек по умолчанию):
 *   1) спокойное лицо (jumpscare_face_1_calm.png) — первая треть времени
 *   2) растянутая улыбка (jumpscare_face_2_smile.png) — вторая треть
 *   3) чёрные глаза, очень страшно (jumpscare_face_3_scary.png) — последняя треть,
 *      на весь экран, максимальная яркость/резкость.
 *   Звук нарастает по громкости от стадии к стадии — это делает сервер (ShejaEntity /
 *   SleepAndGlitchHandler), проигрывая scare_rise на переходе 1->2 и scare_scream на 2->3.
 *   Смерть игрока приходит с сервера отдельным вызовом, синхронизированным по времени.
 *
 * WINDOW_GLIMPSE (короткая версия, ~15-20 тиков):
 *   Одно случайное лицо на весь экран на пару кадров, без плавных переходов — это должно
 *   быть похоже на "померещилось", а не на постановочный ужас.
 */
@Mod.EventBusSubscriber(modid = "horrormod", value = Dist.CLIENT)
public class JumpscareOverlay {

    private static final ResourceLocation FACE_CALM =
            new ResourceLocation("horrormod", "textures/gui/jumpscare_face_1_calm.png");
    private static final ResourceLocation FACE_SMILE =
            new ResourceLocation("horrormod", "textures/gui/jumpscare_face_2_smile.png");
    private static final ResourceLocation FACE_SCARY =
            new ResourceLocation("horrormod", "textures/gui/jumpscare_face_3_scary.png");

    private static final Random RANDOM = new Random();

    private static JumpscarePacket.Mode activeMode = null;
    private static int ticksRemaining = 0;
    private static int totalDuration = 0;
    private static ResourceLocation glimpseFace = FACE_SCARY;

    public static void trigger(JumpscarePacket.Mode mode, int durationTicks) {
        activeMode = mode;
        ticksRemaining = durationTicks;
        totalDuration = durationTicks;
        if (mode == JumpscarePacket.Mode.WINDOW_GLIMPSE) {
            ResourceLocation[] options = { FACE_CALM, FACE_SMILE, FACE_SCARY };
            glimpseFace = options[RANDOM.nextInt(options.length)];
        }
    }

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (activeMode == null || ticksRemaining <= 0) return;
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.HELMET.id())) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        if (activeMode == JumpscarePacket.Mode.WINDOW_GLIMPSE) {
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            graphics.blit(glimpseFace, 0, 0, width, height, 0, 0, 256, 256, 256, 256);
        } else {
            int elapsed = totalDuration - ticksRemaining;

            // Реальный тайминг под вырезанный звук: 9 сек нарастания (спокойное лицо -> улыбка)
            // + 7 сек крика (чёрные глаза). Пропорции могут отличаться от totalDuration, если
            // сервер пришлёт другое значение — тогда просто масштабируем 9:7 по факту.
            float buildFraction = 9.0F / 16.0F;
            float buildEnd = totalDuration * buildFraction;
            float calmEnd = buildEnd / 2.0F;

            ResourceLocation currentFace;
            if (elapsed < calmEnd) {
                currentFace = FACE_CALM;
            } else if (elapsed < buildEnd) {
                currentFace = FACE_SMILE;
            } else {
                currentFace = FACE_SCARY;
            }

            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            graphics.blit(currentFace, 0, 0, width, height, 0, 0, 256, 256, 256, 256);

            // Стадия крика — лёгкое дрожание кадра
            if (elapsed >= buildEnd) {
                int shakeX = RANDOM.nextInt(5) - 2;
                int shakeY = RANDOM.nextInt(5) - 2;
                graphics.fill(shakeX, shakeY, width + shakeX, height + shakeY, 0x33000000);
            }
        }

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.disableBlend();

        ticksRemaining--;
        if (ticksRemaining <= 0) {
            activeMode = null;
        }
    }
}
