package com.semga.horrormod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * "Если сфотографировать существо (или посмотреть в подзорную трубу), его лицо выглядит иначе".
 *
 * Это чисто клиентское, локальное для смотрящего игрока состояние — поэтому не требует
 * сети. Используй в своём EntityRenderer<ShejaEntity>: если isLookingThroughDevice() == true,
 * подставляй "искажённый" вариант текстуры лица вместо обычного.
 *
 * Скриншот (F2) физически не проходит через рендер-пайплайн заранее — если хочешь эффект
 * именно "на скриншоте видно другое лицо", проще всего постоянно рендерить сущность с лёгким
 * искажением ТОЛЬКО в один случайный кадр из N (напр. раз в ~2 секунды на 1 тик), не отражая
 * это в обычном воспринимаемом глазом изображении. Ниже — хук под это.
 */
public class ViewingDeviceCheck {

    private static int rareDistortedFrameCooldown = 0;

    /** Проверять в начале рендера сущности. */
    public static boolean isLookingThroughSpyglass() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;
        ItemStack using = mc.player.getUseItem();
        return mc.player.isUsingItem() && using.is(Items.SPYGLASS);
    }

    /**
     * true примерно раз в ~2 секунды на один-единственный кадр — используй это,
     * чтобы на скриншотах и подзорной трубе иногда "случайно" ловилось другое лицо,
     * даже если игрок ничего не заметил невооружённым глазом.
     */
    public static boolean isRareDistortedFrame() {
        if (rareDistortedFrameCooldown > 0) {
            rareDistortedFrameCooldown--;
            return false;
        }
        if (Math.random() < 1.0 / 40.0) { // ~раз в 40 отрендеренных кадров сущности
            rareDistortedFrameCooldown = 30;
            return true;
        }
        return false;
    }
}
