package com.semga.horrormod.event;

import com.semga.horrormod.HorrorMod;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * "Когда игрок наиграл 4 часа — включается песня, потом просто доигрывает до конца и всё".
 *
 * Использует ванильную статистику "время в игре" (Stats.PLAY_TIME) — это суммарное время
 * во всех заходах в мир, а не текущая сессия. Срабатывает РОВНО ОДИН РАЗ: флаг сохраняется
 * в persistent-данных игрока, так что при повторном входе песня не запустится снова.
 * Дальше ничего специально не останавливаем — .ogg длиной ~17 секунд доигрывает сам и
 * замолкает, как обычный звук.
 */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public class MysterySongHandler {

    private static final long FOUR_HOURS_TICKS = 20L * 60 * 60 * 4;
    private static final String NBT_KEY = "mystery_song_played";

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            CompoundTag modData = getModData(player);
            if (modData.getBoolean(NBT_KEY)) continue; // уже играла — больше никогда не включаем

            long playTicks = player.getStats().getValue(Stats.CUSTOM.get(Stats.PLAY_TIME));
            if (playTicks >= FOUR_HOURS_TICKS) {
                player.level().playSound(null, player.blockPosition(),
                        ModSounds.MYSTERY_SONG.get(), SoundSource.RECORDS, 1.0F, 1.0F);

                modData.putBoolean(NBT_KEY, true);
                saveModData(player, modData);
            }
        }
    }

    private static CompoundTag getModData(ServerPlayer player) {
        CompoundTag persistent = player.getPersistentData();
        return persistent.getCompound(HorrorMod.MODID);
    }

    private static void saveModData(ServerPlayer player, CompoundTag modData) {
        player.getPersistentData().put(HorrorMod.MODID, modData);
    }
}
