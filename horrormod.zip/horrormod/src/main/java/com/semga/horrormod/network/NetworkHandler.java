package com.semga.horrormod.network;

import com.semga.horrormod.HorrorMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class NetworkHandler {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(HorrorMod.MODID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    public static void register() {
        CHANNEL.registerMessage(packetId++, JumpscarePacket.class,
                JumpscarePacket::encode, JumpscarePacket::decode, JumpscarePacket::handle);
        CHANNEL.registerMessage(packetId++, AmbientEventPacket.class,
                AmbientEventPacket::encode, AmbientEventPacket::decode, AmbientEventPacket::handle);
        CHANNEL.registerMessage(packetId++, WindowFacePacket.class,
                WindowFacePacket::encode, WindowFacePacket::decode, WindowFacePacket::handle);
    }
}
