package com.semga.horrormod.event;

import com.semga.horrormod.HorrorMod;
import com.semga.horrormod.network.JumpscarePacket;
import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.network.WindowFacePacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * "Если долго смотреть в окно, там иногда появляется улыбающееся лицо. Если продолжать
 * смотреть на него ещё 10 секунд — оно убивает."
 *
 * Работает с любым блоком, в реестровом имени которого есть "glass" — то есть обычное
 * стекло, стеклянные панели и все цветные варианты автоматически считаются "окном".
 */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public class WindowWatcherHandler {

    private static final Random RANDOM = new Random();
    private static final double REACH = 20.0;

    // Сколько нужно непрерывно смотреть в окно, ПРЕЖДЕ чем лицо вообще сможет появиться.
    private static final int LONG_LOOK_TICKS = 300; // ~15 секунд

    // После порога — шанс появления лица за каждый последующий тик (не мгновенно, чтобы
    // не было ощущения "таймера", а было похоже на редкое совпадение).
    private static final float APPEAR_CHANCE_PER_TICK = 1F / 100F;

    // Сколько смотреть НА УЖЕ ПОЯВИВШЕЕСЯ лицо, чтобы оно убило.
    private static final int DEATH_TICKS = 200; // 10 секунд

    private static class WatchState {
        BlockPos watchedPos = null;
        int lookTicks = 0;
        boolean faceShown = false;
        int faceLookTicks = 0;
    }

    private static final Map<ServerPlayer, WatchState> states = new HashMap<>();

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            WatchState state = states.computeIfAbsent(player, p -> new WatchState());
            tickPlayer(player, state);
        }
    }

    private static void tickPlayer(ServerPlayer player, WatchState state) {
        BlockPos windowPos = raycastWindow(player);
        boolean sameWindowAsBefore = windowPos != null && windowPos.equals(state.watchedPos);

        if (windowPos == null || !sameWindowAsBefore) {
            // Отвернулся / смотрит в другое окно — лицо (если было) прячется, всё сбрасывается
            if (state.faceShown) {
                hideFace(player, state);
            }
            state.watchedPos = windowPos;
            state.lookTicks = windowPos != null ? 1 : 0;
            return;
        }

        state.lookTicks++;

        if (!state.faceShown) {
            if (state.lookTicks >= LONG_LOOK_TICKS && RANDOM.nextFloat() < APPEAR_CHANCE_PER_TICK) {
                state.faceShown = true;
                state.faceLookTicks = 0;
                NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                        new WindowFacePacket(true, windowPos));
            }
        } else {
            state.faceLookTicks++;
            if (state.faceLookTicks >= DEATH_TICKS) {
                killPlayer(player, state);
            }
        }
    }

    private static void hideFace(ServerPlayer player, WatchState state) {
        state.faceShown = false;
        state.faceLookTicks = 0;
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new WindowFacePacket(false, BlockPos.ZERO));
    }

    private static void killPlayer(ServerPlayer player, WatchState state) {
        // Полная страшная последовательность (спокойное -> улыбка -> чёрные глаза + звук) и смерть
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new JumpscarePacket(JumpscarePacket.Mode.FULL_DEATH_SEQUENCE, 320));

        player.getServer().tell(new net.minecraft.server.TickTask(320, () -> {
            if (player.isAlive()) {
                player.hurt(player.damageSources().magic(), Float.MAX_VALUE);
            }
        }));

        hideFace(player, state);
        state.watchedPos = null;
        state.lookTicks = 0;
    }

    private static BlockPos raycastWindow(ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        Vec3 end = eye.add(look.scale(REACH));

        ClipContext ctx = new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player);
        BlockHitResult hit = player.level().clip(ctx);
        if (hit.getType() != HitResult.Type.BLOCK) return null;

        BlockPos pos = hit.getBlockPos();
        BlockState state = player.level().getBlockState(pos);
        return isWindow(state) ? pos : null;
    }

    private static boolean isWindow(BlockState state) {
        var id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        return id != null && id.getPath().contains("glass");
    }
}
