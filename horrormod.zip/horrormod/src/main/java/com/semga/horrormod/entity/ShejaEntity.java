package com.semga.horrormod.entity;

import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.network.JumpscarePacket;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.EnumSet;
import java.util.Random;

/**
 * "Шея" / "Мать искажений".
 *
 * Поведение по дистанции:
 *  - 50-11 блоков: статуй-механика — двигается ближе ТОЛЬКО пока игрок не смотрит на неё
 *    напрямую (как в SCP/Weeping Angels). Если игрок посмотрел на неё, постоял, отвернулся
 *    и посмотрел снова — есть шанс, что она просто исчезнет вместо приближения.
 *  - <=10 блоков: срывается с места и атакует.
 *
 * Почти не издаёт звуков — тишина важнее шума. Внешний вид (искажение лица) прогрессирует
 * от количества прошедших игровых дней и от дистанции до игрока; фактическая отрисовка
 * (выбор текстуры/модели) делается в клиентском рендерере через getDistortionStage()/
 * getExpressionStage(), т.к. модель/арт делаешь ты сам.
 */
public class ShejaEntity extends Monster {

    private static final double WATCH_RANGE = 50.0;
    private static final double CHARGE_RANGE = 10.0;
    private static final Random RANDOM = new Random();

    private int chargeCooldown = 0;

    public ShejaEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.ATTACK_DAMAGE, 0.0D)
                .add(Attributes.FOLLOW_RANGE, WATCH_RANGE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new ChargeAndScareGoal(this));
        this.goalSelector.addGoal(1, new StatueApproachGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, (float) WATCH_RANGE));
    }

    @Override
    public boolean isPersistenceRequired() {
        return true;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (chargeCooldown > 0) chargeCooldown--;

        // Очень редкое дыхание/шаги в тишине — почти неслышно, чтобы не превращать в "звуковой" моб.
        if (!this.level().isClientSide && RANDOM.nextInt(1200) == 0) {
            this.level().playSound(null, this.blockPosition(),
                    ModSounds.WHISPER.get(), SoundSource.AMBIENT, 0.15F, 0.6F);
        }
    }

    /**
     * 0..5 — насколько искажено лицо в принципе, растёт с прошедшими игровыми днями.
     * Используй в рендерере для выбора варианта текстуры/слоя модели.
     */
    public int getDistortionStage() {
        long day = this.level().getDayTime() / 24000L;
        return (int) Math.min(5, day);
    }

    /**
     * 0..1 — насколько "растянута улыбка" прямо сейчас, в зависимости от дистанции до игрока.
     * Меняется плавно (не скачком), рендерер может линейно интерполировать между текстурами.
     */
    public float getExpressionStage(double distanceToPlayer) {
        double clamped = Math.max(CHARGE_RANGE, Math.min(WATCH_RANGE, distanceToPlayer));
        return 1.0F - (float) ((clamped - CHARGE_RANGE) / (WATCH_RANGE - CHARGE_RANGE));
    }

    /**
     * Статуй-механика: приближается рывками, только пока никто не смотрит прямо на неё.
     * Иногда вместо приближения — просто исчезает.
     */
    static class StatueApproachGoal extends Goal {
        private static final float VIEW_COS_THRESHOLD = 0.85F; // ~± 30° конус зрения игрока
        private final ShejaEntity mob;
        private int unwatchedTicks = 0;
        private int glimpseCooldown = 0;

        StatueApproachGoal(ShejaEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.noneOf(Goal.Flag.class)); // не мешает остальным целям/навигации
        }

        @Override
        public boolean canUse() {
            Player nearest = mob.level().getNearestPlayer(mob, WATCH_RANGE);
            return nearest != null && mob.distanceTo(nearest) > CHARGE_RANGE;
        }

        @Override
        public void tick() {
            Player player = mob.level().getNearestPlayer(mob, WATCH_RANGE);
            if (player == null) return;

            boolean watched = isPlayerLookingAtMob(player, mob);

            if (watched) {
                if (unwatchedTicks > 20 && RANDOM.nextFloat() < 0.15F) {
                    // "смотрел, отвернулся, посмотрел снова" — а её уже нет
                    mob.discard();
                    return;
                }
                unwatchedTicks = 0;
            } else {
                unwatchedTicks++;

                if (unwatchedTicks % 30 == 0) {
                    Vec3 toPlayer = player.position().subtract(mob.position()).normalize();
                    double step = 2.0 + RANDOM.nextDouble() * 3.0; // 2-5 блоков за раз
                    double newDist = Math.max(CHARGE_RANGE + 0.5, mob.distanceTo(player) - step);
                    Vec3 dest = player.position().subtract(toPlayer.scale(newDist));
                    mob.teleportTo(dest.x, dest.y, dest.z);
                    mob.getLookControl().setLookAt(player, 180F, 180F);
                }
            }

            // Редкий "взгляд издалека" — на долю секунды резко смотрит прямо на игрока
            // даже с большой дистанции, потом отворачивается как ни в чём не бывало.
            if (glimpseCooldown > 0) {
                glimpseCooldown--;
            } else if (mob.distanceTo(player) > 30.0 && RANDOM.nextInt(400) == 0) {
                mob.getLookControl().setLookAt(player, 360F, 360F);
                glimpseCooldown = 30 + RANDOM.nextInt(60);
            }
        }

        private static boolean isPlayerLookingAtMob(Player player, ShejaEntity mob) {
            Vec3 look = player.getViewVector(1.0F).normalize();
            Vec3 toMob = mob.position().add(0, mob.getBbHeight() / 2, 0)
                    .subtract(player.getEyePosition()).normalize();
            return look.dot(toMob) > VIEW_COS_THRESHOLD;
        }
    }

    /** Ближний бой: рывок -> контакт -> jumpscare. */
    static class ChargeAndScareGoal extends Goal {
        private final ShejaEntity mob;
        private boolean charging = false;

        ChargeAndScareGoal(ShejaEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Player nearest = mob.level().getNearestPlayer(mob, WATCH_RANGE);
            return nearest != null && mob.chargeCooldown <= 0;
        }

        @Override
        public void start() {
            charging = false;
        }

        @Override
        public void tick() {
            Player target = mob.level().getNearestPlayer(mob, WATCH_RANGE);
            if (target == null) return;

            double dist = mob.distanceTo(target);

            if (dist <= CHARGE_RANGE) {
                charging = true;
                mob.getNavigation().moveTo(target, 2.4D);
                mob.getLookControl().setLookAt(target, 180F, 180F);

                if (dist <= 1.6D) {
                    onCatchPlayer(target);
                }
            } else if (charging) {
                charging = false;
                mob.getNavigation().stop();
            }
        }

        @Override
        public boolean canContinueToUse() {
            return charging;
        }

        private void onCatchPlayer(Player player) {
            if (!(player instanceof ServerPlayer serverPlayer)) return;

            NetworkHandler.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> serverPlayer),
                    new JumpscarePacket(JumpscarePacket.Mode.WINDOW_GLIMPSE, 15)
            );

            player.setHealth(1.0F);
            BlockPos bed = player.getRespawnPosition();
            if (bed != null) {
                player.teleportTo(bed.getX() + 0.5, bed.getY() + 0.2, bed.getZ() + 0.5);
            }

            player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
            player.level().playSound(null, player.blockPosition(),
                    ModSounds.SCREAM.get(), SoundSource.HOSTILE, 1.5F, 0.9F);

            mob.discard();
        }
    }
}
