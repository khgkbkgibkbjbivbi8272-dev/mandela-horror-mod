package com.semga.horrormod.event;

import com.semga.horrormod.HorrorMod;
import com.semga.horrormod.network.JumpscarePacket;
import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * "Паралич" / "Присутствие" — событие сна.
 *
 * Специально сделано РЕДКИМ (по просьбе — "паралич редко, а не всегда"): большинство попыток
 * лечь спать проходят спокойно. Если паралич всё-таки начался — это гарантированно ведёт
 * к полной 3-стадийной последовательности (спокойное лицо -> улыбка -> чёрные глаза) с
 * нарастающим по громкости криком и смертью игрока в конце. Это НЕ шанс 50/50 внутри самого
 * события — раз паралич начался, он всегда доигрывается до конца этим сценарием.
 */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public class SleepAndGlitchHandler {

    private static final Random RANDOM = new Random();

    private static final Map<ServerPlayer, Integer> sleepTimers = new HashMap<>();

    // Шанс паралича за одну попытку сна — намеренно низкий, это редкое событие.
    private static final float PARALYSIS_CHANCE = 0.06F;

    // Длительность всей последовательности под реальный вырезанный звук: 9с нарастания + 7с крика.
    private static final int BUILD_TICKS = 180;   // 9 секунд — спокойное лицо -> улыбка, играет scare_rise
    private static final int SCREAM_TICKS = 140;  // 7 секунд — чёрные глаза, играет scare_scream
    private static final int SEQUENCE_DURATION = BUILD_TICKS + SCREAM_TICKS; // 320 тиков = 16 секунд

    @SubscribeEvent
    public static void onSleep(PlayerSleepInBedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            sleepTimers.put(player, 0);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        sleepTimers.entrySet().removeIf(entry -> {
            ServerPlayer player = entry.getKey();
            if (!player.isSleeping()) return true; // проснулся/встал — сбрасываем, ничего не было

            int ticks = entry.getValue() + 1;

            // Через 3-5 секунд (60-100 тиков) после засыпания решаем — паралич или нет
            if (ticks == 80) {
                if (RANDOM.nextFloat() < PARALYSIS_CHANCE) {
                    startParalysis(player);
                }
            }
            entry.setValue(ticks);
            return false;
        });
    }

    private static void startParalysis(ServerPlayer player) {
        // Слепота на время шёпота — "не можешь двигаться, экран тёмный, но не просыпаешься"
        player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20 * 55, 0, false, false));
        player.level().playSound(null, player.blockPosition(),
                ModSounds.WHISPER.get(), SoundSource.AMBIENT, 1.0F, 0.8F);

        // ~минута шёпота, затем запускается сама последовательность лица
        player.getServer().tell(new net.minecraft.server.TickTask(1200, () -> {
            if (!player.isAlive()) return;
            runFullSequence(player);
        }));
    }

    /**
     * Спокойное лицо -> улыбка -> чёрные глаза, звук нарастает по громкости на каждом переходе,
     * в конце — громкий крик и смерть игрока.
     */
    private static void runFullSequence(ServerPlayer player) {
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new JumpscarePacket(JumpscarePacket.Mode.FULL_DEATH_SEQUENCE, SEQUENCE_DURATION));

        // Стадия 1+2 (спокойное лицо -> улыбка) — сразу играет нарастающий звук на все 9 секунд
        player.level().playSound(null, player.blockPosition(),
                ModSounds.SCARE_RISE.get(), SoundSource.HOSTILE, 1.3F, 1.0F);

        // Стадия 3 (чёрные глаза) — ровно на границе начинается сам крик
        player.getServer().tell(new net.minecraft.server.TickTask(BUILD_TICKS, () -> {
            if (!player.isAlive()) return;
            player.level().playSound(null, player.blockPosition(),
                    ModSounds.SCARE_SCREAM.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
        }));

        // Конец последовательности — смерть, синхронизирована с окончанием оверлея на клиенте
        player.getServer().tell(new net.minecraft.server.TickTask(SEQUENCE_DURATION, () -> {
            if (!player.isAlive()) return;
            player.hurt(player.damageSources().magic(), Float.MAX_VALUE);
        }));
    }
}
