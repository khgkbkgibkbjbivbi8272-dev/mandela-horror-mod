package com.semga.horrormod.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Показать скример на клиенте.
 *
 * FULL_DEATH_SEQUENCE — тот самый сценарий "паралич": спокойное лицо -> растянутая улыбка ->
 *   чёрные глаза (страшно) на весь экран, крик нарастает по громкости и заканчивается воплем.
 *   После этой последовательности игрок гарантированно умирает (смерть отправляется отдельно
 *   с сервера по таймеру, синхронизированному с длительностью).
 *
 * WINDOW_GLIMPSE — короткая версия: одно случайное лицо мелькает (например, в окне) и коротко
 *   кричит, без смерти. Может происходить сама по себе, не только во время сна.
 */
public class JumpscarePacket {

    public enum Mode {
        FULL_DEATH_SEQUENCE,
        WINDOW_GLIMPSE
    }

    private final Mode mode;
    private final int totalDurationTicks;

    public JumpscarePacket(Mode mode, int totalDurationTicks) {
        this.mode = mode;
        this.totalDurationTicks = totalDurationTicks;
    }

    public static void encode(JumpscarePacket packet, FriendlyByteBuf buf) {
        buf.writeEnum(packet.mode);
        buf.writeInt(packet.totalDurationTicks);
    }

    public static JumpscarePacket decode(FriendlyByteBuf buf) {
        return new JumpscarePacket(buf.readEnum(Mode.class), buf.readInt());
    }

    public static void handle(JumpscarePacket packet, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() ->
                com.semga.horrormod.client.JumpscareOverlay.trigger(packet.mode, packet.totalDurationTicks));
        ctx.setPacketHandled(true);
    }
}
