package com.semga.horrormod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

/**
 * Рендерит улыбающееся лицо прямо "в окне" — billboard-квад на месте блока стекла,
 * который всегда развёрнут лицом к камере. Активируется/деактивируется через
 * WindowFacePacket (см. WindowWatcherHandler на сервере).
 *
 * ПРИМЕЧАНИЕ: это самая "хрупкая" к версии Forge/Minecraft часть кода — сигнатуры
 * VertexConsumer.vertex(...) иногда чуть отличаются между минорными версиями 1.20.x.
 * Если при сборке ругается на endVertex()/uv2()/overlayCoords() — поправь порядок
 * вызовов по официальному Forge MDK для твоей точной версии, сама идея (billboard-квад
 * на BlockPos) останется той же.
 */
@Mod.EventBusSubscriber(modid = "horrormod", value = Dist.CLIENT)
public class WindowFaceRenderer {

    private static final ResourceLocation FACE_TEXTURE =
            new ResourceLocation("horrormod", "textures/gui/jumpscare_face_2_smile.png");

    private static BlockPos activePos = null;

    public static void show(BlockPos pos) {
        activePos = pos;
    }

    public static void hide() {
        activePos = null;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (activePos == null) return;
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;

        Camera camera = event.getCamera();
        PoseStack poseStack = event.getPoseStack();

        poseStack.pushPose();

        double x = activePos.getX() + 0.5 - camera.getPosition().x;
        double y = activePos.getY() + 0.5 - camera.getPosition().y;
        double z = activePos.getZ() + 0.5 - camera.getPosition().z;
        poseStack.translate(x, y, z);

        // Billboard: квад всегда развёрнут лицом к камере, "прилипает" к стеклу изнутри
        poseStack.mulPose(camera.rotation());

        float size = 0.85F;
        int light = 15728880; // полная яркость, чтобы лицо не пропадало в темноте у окна

        MultiBufferSource.BufferSource buffers = Minecraft.getInstance().renderBuffers().bufferSource();
        RenderType renderType = RenderType.entityTranslucentEmissive(FACE_TEXTURE);
        VertexConsumer consumer = buffers.getBuffer(renderType);
        Matrix4f mat = poseStack.last().pose();

        consumer.vertex(mat, -size, -size, 0f).color(255, 255, 255, 255)
                .uv(0f, 1f).overlayCoords(0, 10).uv2(light).normal(0, 0, 1).endVertex();
        consumer.vertex(mat, size, -size, 0f).color(255, 255, 255, 255)
                .uv(1f, 1f).overlayCoords(0, 10).uv2(light).normal(0, 0, 1).endVertex();
        consumer.vertex(mat, size, size, 0f).color(255, 255, 255, 255)
                .uv(1f, 0f).overlayCoords(0, 10).uv2(light).normal(0, 0, 1).endVertex();
        consumer.vertex(mat, -size, size, 0f).color(255, 255, 255, 255)
                .uv(0f, 0f).overlayCoords(0, 10).uv2(light).normal(0, 0, 1).endVertex();

        buffers.endBatch(renderType);

        poseStack.popPose();
    }
}
