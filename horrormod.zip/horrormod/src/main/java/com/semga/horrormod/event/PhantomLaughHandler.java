package com.semga.horrormod.event;

import com.semga.horrormod.HorrorMod;
import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.network.WindowFacePacket;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * "Раз в 1-2 часа — смех, и за спиной появляется то же лицо, что и в окне.
 * Если обернуться — оно пропадает, но не сразу."
 *
 * Использует тот же билборд-рендер, что и "лицо в окне" (WindowFacePacket /
 * WindowFaceRenderer), просто на другой позиции — прямо за спиной игрока в момент события.
 */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public class PhantomLaughHandler {

    private static final Random RANDOM = new Random();

    private static final int MIN_INTERVAL = 20 * 60 * 60;      // 1 час
    private static final int MAX_INTERVAL = 20 * 60 * 60 * 2;   // 2 часа

    // Конус, при котором считаем, что игрок "обернулся и смотрит" на лицо
    private static final float VIEW_COS_THRESHOLD = 0.8F;

    // Сколько нужно НЕПРЕРЫВНО смотреть на него, прежде чем оно пропадёт — "не сразу"
    private static final int DISAPPEAR_DELAY_TICKS = 45; // ~2.5 секунды

    // На случай, если игрок так и не обернётся — событие само уберётся через это время
    private static final int MAX_LIFETIME_TICKS = 20 * 12; // 12 секунд

    private static class PhantomState {
        int nextEventTicks = MIN_INTERVAL + new Random().nextInt(MAX_INTERVAL - MIN_INTERVAL);
        boolean active = false;
        BlockPos phantomPos = null;
        int watchedTicks = 0;
        int lifetimeTicks = 0;
    }

    private static final Map<ServerPlayer, PhantomState> states = new HashMap<>();

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            PhantomState state = states.computeIfAbsent(player, p -> new PhantomState());
            tickPlayer(player, state);
        }
    }

    private static void tickPlayer(ServerPlayer player, PhantomState state) {
        if (!state.active) {
            state.nextEventTicks--;
            if (state.nextEventTicks <= 0) {
                triggerLaugh(player, state);
            }
            return;
        }

        state.lifetimeTicks++;

        boolean lookingAtPhantom = isLookingAt(player, state.phantomPos);
        if (lookingAtPhantom) {
            state.watchedTicks++;
            if (state.watchedTicks >= DISAPPEAR_DELAY_TICKS) {
                hidePhantom(player, state);
                return;
            }
        } else {
            state.watchedTicks = 0; // отвернулся раньше времени — таймер исчезновения сбрасывается
        }

        if (state.lifetimeTicks >= MAX_LIFETIME_TICKS) {
            hidePhantom(player, state);
        }
    }

    private static void triggerLaugh(ServerPlayer player, PhantomState state) {
        Vec3 look = player.getViewVector(1.0F).normalize();
        // Позиция строго за спиной игрока, на уровне глаз, в паре блоков позади
        Vec3 behind = player.getEyePosition().subtract(look.scale(2.5));
        BlockPos phantomPos = BlockPos.containing(behind);

        player.level().playSound(null, player.blockPosition(),
                ModSounds.LAUGH.get(), SoundSource.HOSTILE, 1.0F, 1.0F);

        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new WindowFacePacket(true, phantomPos));

        state.active = true;
        state.phantomPos = phantomPos;
        state.watchedTicks = 0;
        state.lifetimeTicks = 0;
    }

    private static void hidePhantom(ServerPlayer player, PhantomState state) {
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new WindowFacePacket(false, BlockPos.ZERO));

        state.active = false;
        state.phantomPos = null;
        state.watchedTicks = 0;
        state.lifetimeTicks = 0;
        state.nextEventTicks = MIN_INTERVAL + RANDOM.nextInt(MAX_INTERVAL - MIN_INTERVAL);
    }

    private static boolean isLookingAt(ServerPlayer player, BlockPos pos) {
        if (pos == null) return false;
        Vec3 look = player.getViewVector(1.0F).normalize();
        Vec3 toTarget = Vec3.atCenterOf(pos).subtract(player.getEyePosition()).normalize();
        return look.dot(toTarget) > VIEW_COS_THRESHOLD;
    }
}
