package com.semga.horrormod.entity;

import com.semga.horrormod.HorrorMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HorrorMod.MODID);

    public static final RegistryObject<EntityType<ShejaEntity>> SHEJA = ENTITY_TYPES.register(
            "sheja",
            () -> EntityType.Builder.of(ShejaEntity::new, MobCategory.MONSTER)
                    .sized(0.7f, 2.3f)     // модель повыше обычного моба
                    .clientTrackingRange(16)
                    .build("sheja")
    );
}
