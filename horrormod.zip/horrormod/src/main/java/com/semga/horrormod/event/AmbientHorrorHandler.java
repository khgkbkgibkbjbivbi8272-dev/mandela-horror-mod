package com.semga.horrormod.event;

import com.semga.horrormod.HorrorMod;
import com.semga.horrormod.entity.ShejaEntity;
import com.semga.horrormod.network.AmbientEventPacket;
import com.semga.horrormod.network.JumpscarePacket;
import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;
import java.util.Random;

/**
 * Всё, что НЕ является прямой атакой: мелкие фоновые эффекты, которые должны заставлять
 * игрока сомневаться "было это или показалось". Частота специально нарастает вместе
 * с игровыми днями — мир становится "опаснее" по мере прохождения.
 */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public class AmbientHorrorHandler {

    private static final Random RANDOM = new Random();
    private static final java.util.Map<ServerPlayer, Integer> nextFaceGlimpse = new java.util.HashMap<>();
    private static final java.util.Map<ServerPlayer, Integer> nextScreenGlitch = new java.util.HashMap<>();

    // Базовые интервалы в тиках (20 тиков = 1 сек), уменьшаются с ростом дня — события учащаются.
    private static final int LIGHT_FLICKER_BASE_INTERVAL = 20 * 60 * 60 * 3; // ~раз в 3 часа игрового времени сервера
    private static final int DOOR_GLITCH_BASE_INTERVAL = 20 * 60 * 25;       // ~раз в 25 минут
    private static final int PHANTOM_STEP_BASE_INTERVAL = 20 * 60 * 8;      // ~раз в 8 минут
    private static final int SILHOUETTE_BASE_INTERVAL = 20 * 60 * 12;       // ~раз в 12 минут
    // "Одно из лиц мелькает (например, в окне) и коротко кричит" — раз в 10-15 минут в среднем
    private static final int FACE_GLIMPSE_MIN_INTERVAL = 20 * 60 * 10;
    private static final int FACE_GLIMPSE_MAX_INTERVAL = 20 * 60 * 15;

    // Помехи на экране — тоже раз в 10-15 минут, отдельным случайным интервалом на игрока
    private static final int SCREEN_GLITCH_MIN_INTERVAL = 20 * 60 * 10;
    private static final int SCREEN_GLITCH_MAX_INTERVAL = 20 * 60 * 15;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (player.isSleeping()) continue; // во время сна — своя механика паралича

            ServerLevel level = (ServerLevel) player.level();
            long day = level.getDayTime() / 24000L;
            // Чем больше дней прошло, тем чаще события — но не быстрее разумного минимума.
            float speedup = 1.0F + Math.min(day, 10) * 0.15F; // до +150% частоты к 10-му дню

            if (RANDOM.nextInt(scaled(LIGHT_FLICKER_BASE_INTERVAL, speedup)) == 0) {
                sendAmbient(player, AmbientEventPacket.Type.LIGHT_FLICKER);
            }
            if (RANDOM.nextInt(scaled(SILHOUETTE_BASE_INTERVAL, speedup)) == 0) {
                sendAmbient(player, AmbientEventPacket.Type.SILHOUETTE);
            }
            if (RANDOM.nextInt(scaled(PHANTOM_STEP_BASE_INTERVAL, speedup)) == 0) {
                phantomFootsteps(player);
            }
            if (RANDOM.nextInt(scaled(DOOR_GLITCH_BASE_INTERVAL, speedup)) == 0) {
                toggleUnseenDoor(player, level);
            }

            tickScreenGlitch(player);
            tickFaceGlimpse(player);
        }
    }

    /** Помехи на экране — фиксированный интервал 10-15 минут на игрока (не зависит от дня). */
    private static void tickScreenGlitch(ServerPlayer player) {
        int remaining = nextScreenGlitch.getOrDefault(player,
                SCREEN_GLITCH_MIN_INTERVAL + RANDOM.nextInt(SCREEN_GLITCH_MAX_INTERVAL - SCREEN_GLITCH_MIN_INTERVAL));

        remaining--;
        if (remaining <= 0) {
            sendAmbient(player, AmbientEventPacket.Type.SCREEN_GLITCH);
            remaining = SCREEN_GLITCH_MIN_INTERVAL + RANDOM.nextInt(SCREEN_GLITCH_MAX_INTERVAL - SCREEN_GLITCH_MIN_INTERVAL);
        }
        nextScreenGlitch.put(player, remaining);
    }

    /**
     * "Одно из лиц можно увидеть, например, в окне — и оно заорёт". Не связано со сном
     * и не убивает игрока, просто пугает. Срабатывает раз в 10-15 минут на игрока.
     */
    private static void tickFaceGlimpse(ServerPlayer player) {
        int remaining = nextFaceGlimpse.getOrDefault(player,
                FACE_GLIMPSE_MIN_INTERVAL + RANDOM.nextInt(FACE_GLIMPSE_MAX_INTERVAL - FACE_GLIMPSE_MIN_INTERVAL));

        remaining--;
        if (remaining <= 0) {
            NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new JumpscarePacket(JumpscarePacket.Mode.WINDOW_GLIMPSE, 18));
            player.level().playSound(null, player.blockPosition(),
                    ModSounds.SCARE_SCREAM.get(), SoundSource.HOSTILE, 0.8F, 1.1F);

            remaining = FACE_GLIMPSE_MIN_INTERVAL + RANDOM.nextInt(FACE_GLIMPSE_MAX_INTERVAL - FACE_GLIMPSE_MIN_INTERVAL);
        }
        nextFaceGlimpse.put(player, remaining);
    }

    private static int scaled(int baseInterval, float speedup) {
        return Math.max(200, (int) (baseInterval / speedup));
    }

    private static void sendAmbient(ServerPlayer player, AmbientEventPacket.Type type) {
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new AmbientEventPacket(type));
    }

    /**
     * Звук шагов/дыхания там, где рядом нет ни одного моба "Шеи" — специально проверяем
     * отсутствие сущности, чтобы это выглядело необъяснимо.
     */
    private static void phantomFootsteps(ServerPlayer player) {
        AABB nearby = player.getBoundingBox().inflate(16.0);
        List<ShejaEntity> mobsNearby = player.level().getEntitiesOfClass(ShejaEntity.class, nearby);
        if (!mobsNearby.isEmpty()) return; // рядом реально кто-то есть — это не "фантомный" случай

        Vec3 pos = player.position().add(
                (RANDOM.nextDouble() - 0.5) * 6.0, 0, (RANDOM.nextDouble() - 0.5) * 6.0);
        player.level().playSound(null, BlockPos.containing(pos),
                ModSounds.WHISPER.get(), SoundSource.AMBIENT, 0.3F, 0.5F + RANDOM.nextFloat() * 0.3F);
    }

    /**
     * Находит дверь рядом с игроком, которая сейчас не в его поле зрения, и молча
     * переключает её состояние (открыта/закрыта), пока он не смотрит.
     */
    private static void toggleUnseenDoor(ServerPlayer player, ServerLevel level) {
        BlockPos center = player.blockPosition();
        Vec3 look = player.getViewVector(1.0F).normalize();

        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-8, -2, -8), center.offset(8, 2, 8))) {
            BlockState state = level.getBlockState(pos);
            if (!(state.getBlock() instanceof DoorBlock)) continue;
            if (!state.hasProperty(BlockStateProperties.OPEN)) continue;

            Vec3 toDoor = Vec3.atCenterOf(pos).subtract(player.getEyePosition()).normalize();
            boolean inView = look.dot(toDoor) > 0.5F; // грубая проверка "в поле зрения"
            if (inView) continue; // дверь видна — не трогаем, иначе игрок заметит

            boolean currentlyOpen = state.getValue(BlockStateProperties.OPEN);
            level.setBlock(pos, state.setValue(BlockStateProperties.OPEN, !currentlyOpen), 3);
            return; // за раз — только одна дверь, чтобы не было слишком очевидно
        }
    }
}
