package com.semga.horrormod;

import com.semga.horrormod.entity.ModEntities;
import com.semga.horrormod.entity.ShejaEntity;
import com.semga.horrormod.network.NetworkHandler;
import com.semga.horrormod.sound.ModSounds;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

@Mod(HorrorMod.MODID)
public class HorrorMod {

    public static final String MODID = "horrormod";

    public HorrorMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModSounds.SOUND_EVENTS.register(modEventBus);

        modEventBus.addListener(this::onEntityAttributeCreate);

        NetworkHandler.register();
    }

    private void onEntityAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.SHEJA.get(), ShejaEntity.createAttributes().build());
    }
}
