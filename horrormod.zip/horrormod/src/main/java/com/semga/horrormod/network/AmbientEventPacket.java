package com.semga.horrormod.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Разовые лёгкие фоновые эффекты — никакого урона, просто "жутковато".
 */
public class AmbientEventPacket {

    public enum Type {
        LIGHT_FLICKER,   // свет на мгновение мигает
        SILHOUETTE,      // силуэт за спиной на долю секунды
        SCREEN_GLITCH,   // один кадр помех + лёгкое дрожание экрана
    }

    private final Type type;

    public AmbientEventPacket(Type type) {
        this.type = type;
    }

    public static void encode(AmbientEventPacket packet, FriendlyByteBuf buf) {
        buf.writeEnum(packet.type);
    }

    public static AmbientEventPacket decode(FriendlyByteBuf buf) {
        return new AmbientEventPacket(buf.readEnum(Type.class));
    }

    public static void handle(AmbientEventPacket packet, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> com.semga.horrormod.client.AmbientEffects.trigger(packet.type));
        ctx.setPacketHandled(true);
    }
}
