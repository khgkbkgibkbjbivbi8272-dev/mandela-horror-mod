package com.semga.horrormod.sound;

import com.semga.horrormod.HorrorMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, HorrorMod.MODID);

    // Тихий шёпот, проигрывается пока сущность рядом / во время паралича
    public static final RegistryObject<SoundEvent> WHISPER = registerSound("whisper");

    // Резкий крик перед смертью / скримером
    public static final RegistryObject<SoundEvent> SCREAM = registerSound("scream");

    // Нарастающий звук перед скримером (используется в полной последовательности паралича)
    public static final RegistryObject<SoundEvent> SCARE_RISE = registerSound("scare_rise");

    // Финальный громкий крик — конец последовательности, после него игрок умирает
    public static final RegistryObject<SoundEvent> SCARE_SCREAM = registerSound("scare_scream");

    // Жуткий смех "за спиной" — редкое событие раз в 1-2 часа
    public static final RegistryObject<SoundEvent> LAUGH = registerSound("laugh");

    // Песня, которая включается один раз после 4 часов наигранного времени
    public static final RegistryObject<SoundEvent> MYSTERY_SONG = registerSound("mystery_song");

    // Гул "лагов реальности"
    public static final RegistryObject<SoundEvent> REALITY_HUM = registerSound("reality_hum");

    private static RegistryObject<SoundEvent> registerSound(String name) {
        ResourceLocation id = new ResourceLocation(HorrorMod.MODID, name);
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
}
